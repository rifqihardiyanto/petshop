<!-- partial:partials/_footer.html -->
<footer class="footer">
  <div class="d-sm-flex justify-content-center justify-content-sm-between">
    <span class="text-center text-sm-left d-block d-sm-inline-block">Copyright © <a href="#" target="_blank">Palagan Petshop</a> 2022</span>
  </div>
</footer>
<!-- partial -->

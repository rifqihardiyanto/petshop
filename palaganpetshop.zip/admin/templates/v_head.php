<!-- base:css -->
<link rel="stylesheet" href="../vendor/vendors/typicons.font/font/typicons.css">
<link rel="stylesheet" href="../vendor/vendors/css/vendor.bundle.base.css">
<!-- endinject -->
<!-- plugin css for this page -->
<!-- End plugin css for this page -->
<!-- inject:css -->
<link rel="stylesheet" href="../vendor/css/vertical-layout-light/style.css">
<!-- endinject -->
<link rel="shortcut icon" href="../vendor/images/favicon.png" />

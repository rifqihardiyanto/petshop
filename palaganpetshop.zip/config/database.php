<?php
# LOCAL
$host = 'localhost'; //Host yang digunakan Localhost atau 127.0.0.1
$user = 'rifqipet_user'; //Username dari Host yakni root
$pass = 'rYqoS.n]%vA-'; //User root tidak menggunakan password
$dbname = 'rifqipet_rifqi'; //Nama Database Aplikasi Enkirpsi dan Dekripsi

$connect = new mysqli($host, $user, $pass, $dbname);
?>

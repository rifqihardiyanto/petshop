<?php

header("Location:landing/");

 ?>
